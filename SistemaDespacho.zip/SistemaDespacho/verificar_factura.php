<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['codigo_factura'])) {
    $codigo_factura = $_POST['codigo_factura'];

    $sql = "SELECT COUNT(*) AS total FROM despachos WHERE codigo_factura = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $codigo_factura);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['total'] > 0) {
        echo "existe"; // Factura ya registrada
    } else {
        echo "no_existe"; // Factura no existe, se puede registrar
    }

    $stmt->close();
    $conn->close();
}
?>
