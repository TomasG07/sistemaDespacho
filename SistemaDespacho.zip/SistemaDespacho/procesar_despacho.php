<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_factura = $_POST['codigo_factura'];
    $cliente_codigo = $_POST['cliente_codigo'];
    $usuario_id = $_POST['usuario_id'];
    $fecha_registro = $_POST['fecha'];
    $facturado = $_POST['facturado'];
    $productos = json_decode($_POST['productos'], true);

    if (empty($codigo_factura) || empty($cliente_codigo) || empty($productos)) {
        echo "Error: Todos los campos son obligatorios.";
        exit();
    }

    // Verificar si la factura ya existe
    $stmt = $conn->prepare("SELECT id FROM despachos WHERE codigo_factura = ?");
    $stmt->bind_param("s", $codigo_factura);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "Error: La factura ya está registrada.";
        exit();
    }
    $stmt->close();

    // Insertar en la tabla de despachos
    $total_productos = count($productos);
    $total_despachado = array_sum(array_column($productos, 'cantidad'));

    $stmt = $conn->prepare("INSERT INTO despachos (codigo_factura, cliente_codigo, usuario_id, fecha_registro, facturado, total_productos, total_despachado) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $codigo_factura, $cliente_codigo, $usuario_id, $fecha_registro, $facturado, $total_productos, $total_despachado);

    if ($stmt->execute()) {
        $despacho_id = $stmt->insert_id;
        
        // Insertar productos en detalle_despachos
        foreach ($productos as $producto) {
            $stmt_producto = $conn->prepare("INSERT INTO detalle_despachos (despacho_id, codigo_producto, cantidad) VALUES (?, ?, ?)");
            $stmt_producto->bind_param("sss", $despacho_id, $producto['codigo'], $producto['cantidad']);
            $stmt_producto->execute();
        }

        echo "Despacho registrado correctamente.";
    } else {
        echo "Error al registrar el despacho.";
    }

    $stmt->close();
    $conn->close();
}
?>
