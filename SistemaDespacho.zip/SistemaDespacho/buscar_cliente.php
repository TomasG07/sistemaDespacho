<?php
include 'config.php';

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['busqueda'])) {
    $busqueda = "%" . $_POST['busqueda'] . "%";

    $sql = "SELECT Codigo, NombreCliente FROM clientes WHERE UPPER(NombreCliente) LIKE UPPER(?) OR Codigo LIKE ? LIMIT 10";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ss", $busqueda, $busqueda);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($cliente = $result->fetch_assoc()) {
                echo "<li class='list-group-item cliente-item' 
                        data-codigo='{$cliente['Codigo']}' 
                        data-nombre='{$cliente['NombreCliente']}'>
                        <b>{$cliente['Codigo']}</b> - {$cliente['NombreCliente']}
                      </li>";
            }
        } else {
            echo "<li class='list-group-item text-warning'>No se encontraron clientes.</li>";
        }

        $stmt->close();
    } else {
        echo "<li class='list-group-item text-danger'>Error en la consulta SQL: " . $conn->error . "</li>";
    }

    $conn->close();
}
?>
