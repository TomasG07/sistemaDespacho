<?php
require_once __DIR__ . '/vendor/autoload.php'; // Cargar TCPDF con Composer
include 'config.php';

// Verificar si se recibió el ID del despacho
if (!isset($_GET['despacho_id'])) {
    die("Error: No se proporcionó un ID de despacho.");
}

$despacho_id = intval($_GET['despacho_id']);

// Datos de la empresa
$empresa = [
    "nombre" => "Tecnologías Agrícolas Frailes",
    "direccion" => "Frailes, 900 mts norte del Banco, Antiguo Arthur´s Bar",
    "telefono" => "2544-0005",
    "web" => "https://tecnologiasagricolasfrailes.com/"
];

// Obtener información del despacho
$sql = "SELECT d.codigo_factura, c.NombreCliente AS cliente, d.fecha_registro 
        FROM despachos d
        JOIN clientes c ON d.cliente_codigo = c.codigo
        WHERE d.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $despacho_id);
$stmt->execute();
$result = $stmt->get_result();
$despacho = $result->fetch_assoc();
$stmt->close();

// Obtener productos de la orden de compra original
$sql = "SELECT p.nombre AS producto, dp.cantidad_comprada AS cantidad_original
        FROM despacho_productos dp
        JOIN productos p ON dp.producto_codigo = p.codigo
        WHERE dp.despacho_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $despacho_id);
$stmt->execute();
$orden_compra = $stmt->get_result();
$stmt->close();

// Obtener historial de retiros con cantidad restante
$sql = "SELECT r.fecha_retiro, p.nombre AS producto, r.cantidad_retirada, 
               (SELECT SUM(r1.cantidad_retirada) 
                FROM retiros r1 
                WHERE r1.producto_codigo = r.producto_codigo 
                AND r1.fecha_retiro <= r.fecha_retiro) AS cantidad_restante,
               u.nombre AS usuario
        FROM retiros r
        JOIN productos p ON r.producto_codigo = p.codigo
        JOIN usuarios u ON r.usuario_id = u.id
        WHERE r.despacho_id = ?
        ORDER BY r.fecha_retiro ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $despacho_id);
$stmt->execute();
$historial = $stmt->get_result();
$stmt->close();

// Crear instancia de TCPDF
$pdf = new TCPDF();
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor("Tomas Gomez Garro.");
$pdf->SetTitle("Historial de Retiros - Factura " . $despacho['codigo_factura']);
// Configurar la alineación de los datos junto con el logo
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(40); // Mueve la posición a la derecha
$pdf->Cell(0, 6, $empresa['nombre'], 0, 1, 'L');

$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(40);
$pdf->Cell(0, 6, "Dirección: " . $empresa['direccion'], 0, 1, 'L');
$pdf->Cell(40);
$pdf->Cell(0, 6, "Tel: " . $empresa['telefono'] . " | Web: " . $empresa['web'], 0, 1, 'L');

$pdf->Ln(5); // Espacio debajo del encabezado


// Configurar márgenes
$pdf->SetMargins(15, 20, 15);
$pdf->AddPage();

// Agregar imagen del logo (debe estar en 'images/logo.png')
$pdf->Image('images/logo.png', 15, 10, 30);

// Título principal
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, "Historial de Retiros", 0, 1, 'C');
$pdf->Ln(5);

// Datos del despacho
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(0, 6, "Factura: " . $despacho['codigo_factura'], 0, 1);
$pdf->Cell(0, 6, "Cliente: " . $despacho['cliente'], 0, 1);

// Formatear fecha y hora
$fecha_original = $despacho['fecha_registro'];
$fecha_formateada = date("d/m/Y", strtotime($fecha_original)); // dd/mm/yyyy
$hora_formateada = date("g:i A", strtotime($fecha_original)); // 12h AM/PM

// Mostrar fecha y hora en el PDF
$pdf->Cell(0, 6, "Fecha: " . $fecha_formateada, 0, 1);
$pdf->Cell(0, 6, "Hora: " . $hora_formateada, 0, 1);
$pdf->Ln(5);

// ========================= ORDEN DE COMPRA =========================
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, "Orden de Compra", 0, 1, 'L');
$pdf->Ln(3);

// Encabezado de la tabla
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(90, 7, "Producto", 1);
$pdf->Cell(40, 7, "Cantidad Solicitada", 1);
$pdf->Ln();

// Contenido de la orden de compra
$pdf->SetFont('helvetica', '', 10);
while ($row = $orden_compra->fetch_assoc()) {
    $pdf->Cell(90, 7, $row['producto'], 1);
    $pdf->Cell(40, 7, $row['cantidad_original'] . " unid.", 1);
    $pdf->Ln();
}

$pdf->Ln(5);

// ========================= HISTORIAL DE RETIROS =========================
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, "Historial de Retiros", 0, 1, 'L');
$pdf->Ln(3);

// Encabezado de la tabla con fecha y hora separadas
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(30, 7, "Fecha", 1);
$pdf->Cell(20, 7, "Hora", 1);
$pdf->Cell(60, 7, "Producto", 1);
$pdf->Cell(25, 7, "Cantidad", 1);
$pdf->Cell(25, 7, "Restantes", 1);
$pdf->Cell(30, 7, "Usuario", 1);
$pdf->Ln();

// Contenido de la tabla de retiros
$pdf->SetFont('helvetica', '', 10);
while ($row = $historial->fetch_assoc()) {
    $fecha_retiro = date("d/m/Y", strtotime($row['fecha_retiro']));
    $hora_retiro = date("g:i A", strtotime($row['fecha_retiro']));

    $pdf->Cell(30, 7, $fecha_retiro, 1);
    $pdf->Cell(20, 7, $hora_retiro, 1);
    $pdf->Cell(60, 7, $row['producto'], 1);
    $pdf->Cell(25, 7, $row['cantidad_retirada'] . " unid.", 1);
    $pdf->Cell(25, 7, $row['cantidad_restante'] . " unid.", 1);
    $pdf->Cell(30, 7, $row['usuario'], 1);
    $pdf->Ln();
}

// Cerrar la conexión
$conn->close();

// Generar el PDF y enviarlo al navegador
$pdf->Output("Historial_Factura_" . $despacho['codigo_factura'] . ".pdf", "I");
?>
