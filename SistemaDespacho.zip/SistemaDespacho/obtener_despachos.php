<?php
include 'config.php';

header('Content-Type: application/json');

// Consulta para obtener los despachos pendientes
$sql = "SELECT d.id AS despacho_id, d.codigo_factura, c.NombreCliente AS nombre_cliente, 
               d.fecha_registro, SUM(dp.cantidad) AS cantidad_pendiente
        FROM despachos d
        JOIN clientes c ON d.cliente_codigo = c.codigo
        JOIN despacho_productos dp ON d.id = dp.despacho_id
        WHERE dp.cantidad > 0
        GROUP BY d.id
        ORDER BY d.fecha_registro ASC";

$result = $conn->query($sql);
$despachos = [];

while ($row = $result->fetch_assoc()) {
    $despachos[] = [
        "codigo_factura" => $row["codigo_factura"],
        "nombre_cliente" => $row["nombre_cliente"],
        "fecha_registro" => $row["fecha_registro"],
        "cantidad_pendiente" => $row["cantidad_pendiente"],
        "despacho_id" => $row["despacho_id"]
    ];
}

echo json_encode($despachos);
$conn->close();
?>
