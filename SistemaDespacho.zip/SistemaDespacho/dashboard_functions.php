<?php
function obtenerCantidadDespachosPendientes($conn) {
    $sql = "SELECT COUNT(*) AS total FROM despachos WHERE id IN (SELECT despacho_id FROM despacho_productos WHERE cantidad > 0)";
    $result = $conn->query($sql);
    return $result->fetch_assoc()['total'];
}

function obtenerDespachosHoy($conn) {
    $sql = "SELECT COUNT(*) AS total FROM despachos WHERE DATE(fecha_registro) = CURDATE()";
    $result = $conn->query($sql);
    return $result->fetch_assoc()['total'];
}

function obtenerTotalClientes($conn) {
    $sql = "SELECT COUNT(*) AS total FROM clientes";
    $result = $conn->query($sql);
    return $result->fetch_assoc()['total'];
}

function obtenerProductosStockBajo($conn) {
    $sql = "SELECT COUNT(*) AS total FROM productos WHERE `stock_actual` <= 10"; // Ajusta el umbral según necesites
    $result = $conn->query($sql);
    return $result->fetch_assoc()['total'];
}

function obtenerFechasDespachos($conn) {
    $sql = "SELECT DATE(fecha_registro) as fecha FROM despachos 
            WHERE fecha_registro >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
            GROUP BY DATE(fecha_registro)";
    $result = $conn->query($sql);
    $fechas = [];
    while ($row = $result->fetch_assoc()) {
        $fechas[] = $row['fecha'];
    }
    return $fechas;
}

function obtenerDatosDespachos($conn) {
    $sql = "SELECT DATE(fecha_registro) as fecha, COUNT(*) as total FROM despachos 
            WHERE fecha_registro >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
            GROUP BY DATE(fecha_registro)";
    $result = $conn->query($sql);
    $datos = [];
    while ($row = $result->fetch_assoc()) {
        $datos[] = $row['total'];
    }
    return $datos;
}

function obtenerUltimosDespachos($conn) {
    $sql = "SELECT d.codigo_factura, c.NombreCliente AS nombre_cliente, d.fecha_registro, 
                   SUM(dp.cantidad) AS cantidad_pendiente 
            FROM despachos d
            JOIN clientes c ON d.cliente_codigo = c.codigo
            JOIN despacho_productos dp ON d.id = dp.despacho_id
            GROUP BY d.id
            ORDER BY d.fecha_registro DESC
            LIMIT 5";
    return $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
}
?>
