<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['despacho_id'], $_POST['usuario_id'], $_POST['productos'])) {
        echo "Error: Datos incompletos.";
        exit();
    }

    $despacho_id = intval($_POST['despacho_id']);
    $usuario_id = intval($_POST['usuario_id']);
    $productos = json_decode($_POST['productos'], true);

    if (!$productos) {
        echo "Error: Datos de productos inválidos.";
        exit();
    }

    foreach ($productos as $producto_codigo => $cantidad_retirada) {
        $cantidad_retirada = intval($cantidad_retirada);

        if ($cantidad_retirada <= 0) continue;

        // Verificar la cantidad disponible en despacho_productos
        $sql_verificar = "SELECT cantidad FROM despacho_productos WHERE despacho_id = ? AND producto_codigo = ?";
        $stmt_verificar = $conn->prepare($sql_verificar);
        $stmt_verificar->bind_param("is", $despacho_id, $producto_codigo);
        $stmt_verificar->execute();
        $result = $stmt_verificar->get_result();
        $row = $result->fetch_assoc();
        $cantidad_disponible = $row['cantidad'] ?? 0;

        if ($cantidad_retirada > $cantidad_disponible) {
            echo "Error: No hay suficientes productos para retirar.";
            exit();
        }

        // Registrar retiro
        $sql_insertar = "INSERT INTO retiros (despacho_id, producto_codigo, cantidad_retirada, usuario_id, fecha_retiro) 
                         VALUES (?, ?, ?, ?, NOW())";
        $stmt_insertar = $conn->prepare($sql_insertar);
        $stmt_insertar->bind_param("isii", $despacho_id, $producto_codigo, $cantidad_retirada, $usuario_id);
        $stmt_insertar->execute();

        // Actualizar total_despachado en la tabla despachos
        $sql_actualizar_despacho = "UPDATE despachos SET total_despachado = total_despachado + ? WHERE id = ?";
        $stmt_actualizar_despacho = $conn->prepare($sql_actualizar_despacho);
        $stmt_actualizar_despacho->bind_param("ii", $cantidad_retirada, $despacho_id);
        $stmt_actualizar_despacho->execute();

        // Actualizar cantidad en despacho_productos
        $sql_actualizar_producto = "UPDATE despacho_productos SET cantidad = cantidad - ? WHERE despacho_id = ? AND producto_codigo = ?";
        $stmt_actualizar_producto = $conn->prepare($sql_actualizar_producto);
        $stmt_actualizar_producto->bind_param("iis", $cantidad_retirada, $despacho_id, $producto_codigo);
        $stmt_actualizar_producto->execute();
    }

    echo "Retiro registrado correctamente.";
}
?>
