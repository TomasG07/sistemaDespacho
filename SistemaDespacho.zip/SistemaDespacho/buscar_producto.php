<?php
include 'config.php';

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['busqueda'])) {
    $busqueda = "%" . $_POST['busqueda'] . "%";

    $sql = "SELECT codigo, nombre FROM productos WHERE UPPER(nombre) LIKE UPPER(?) OR codigo LIKE ? LIMIT 10";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ss", $busqueda, $busqueda);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($producto = $result->fetch_assoc()) {
                echo "<li class='list-group-item producto-item' 
                        data-codigo='{$producto['codigo']}' 
                        data-nombre='{$producto['nombre']}'>
                        <b>{$producto['codigo']}</b> - {$producto['nombre']}
                      </li>";
            }
        } else {
            echo "<li class='list-group-item text-warning'>No se encontraron productos.</li>";
        }

        $stmt->close();
    } else {
        echo "<li class='list-group-item text-danger'>Error en la consulta SQL: " . $conn->error . "</li>";
    }

    $conn->close();
}
?>
