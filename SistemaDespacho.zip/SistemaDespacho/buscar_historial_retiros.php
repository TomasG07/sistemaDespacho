<?php
include 'config.php';

if (!isset($_POST['despacho_id'])) {
    echo "<tr><td colspan='5' class='text-center'>Error: No se proporcionó un ID de despacho.</td></tr>";
    exit();
}

$despacho_id = intval($_POST['despacho_id']);

$sql = "SELECT r.fecha_retiro, p.nombre AS producto_nombre, r.cantidad_retirada, 
               (d.total_productos - r.cantidad_retirada) AS cantidad_restante, u.nombre AS usuario_retiro
        FROM retiros r
        JOIN productos p ON r.producto_codigo = p.codigo
        JOIN despachos d ON r.despacho_id = d.id
        JOIN usuarios u ON r.usuario_id = u.id
        WHERE r.despacho_id = ?
        ORDER BY r.fecha_retiro ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $despacho_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['fecha_retiro']}</td>
                <td>{$row['producto_nombre']}</td>
                <td>{$row['cantidad_retirada']} unidades</td>
                <td>{$row['cantidad_restante']} unidades</td>
                <td><strong>{$row['usuario_retiro']}</strong></td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5' class='text-center'>No hay retiros registrados para este despacho.</td></tr>";
}

$stmt->close();
$conn->close();
?>
