<?php
$host = "mysql.datos.tecnologiasagricolasfrailes.com";
$user = "app_despachos";
$password = "070103To";
$database = "despachoabonos";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
